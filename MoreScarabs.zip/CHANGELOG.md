# 1.3.2

Removed unnecessary error report

# 1.3.1

Fixed issue with spawning caused by the patch

Removed incompatibility with Obeliskial Essentials

# 1.3.0

Updated for AtO v1.6.20

# 1.2.0

Removed Obeliskial Essentials requirement. Made it so that Scarabs spawn at the correct time.

# 1.1.0

Update for v1.5.0

Fixed the issue with Scarabs spawning during Round 1.

# 1.0.0

Initial Release
